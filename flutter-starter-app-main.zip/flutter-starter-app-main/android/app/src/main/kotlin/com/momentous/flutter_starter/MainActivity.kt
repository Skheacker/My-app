package com.momentous.flutter_starter

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
